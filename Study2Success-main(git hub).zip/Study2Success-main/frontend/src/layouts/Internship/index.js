// import Form from "pages/Presentation/textform";
// import Form from "pages/Presentation/form";
import InternshipFinder from "pages/Presentation/internship";

export default function Internship() {
  return <InternshipFinder />;
}
