import Form from "pages/Presentation/textform";
// import Form from "pages/Presentation/form";

export default function Forms() {
  return <Form />;
}
