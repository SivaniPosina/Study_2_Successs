// import Form from "pages/Presentation/textform";
// import Form from "pages/Presentation/form";
//import InternshipFinder from "pages/Presentation/internship";
import QForm from "pages/Presentation/Q&A";

export default function QPage() {
  return <QForm />;
}
