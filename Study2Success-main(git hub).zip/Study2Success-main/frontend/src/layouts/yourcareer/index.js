import Yourcareer from "pages/Presentation/yourcareer";

export default function yourcareer() {
  return <Yourcareer />;
}