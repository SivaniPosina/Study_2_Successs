import SignIn from "pages/Presentation/SignIn";

export default function SignInPage() {
  return <SignIn />;
}
