import Feedback from "pages/Presentation/feedback";
export default function AboutUsPage() {
  return <Feedback />;
}
